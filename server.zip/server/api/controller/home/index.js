const db = require('../../model/db.js')
const sql = require('../../model/sql.js')
var URL = require('url')

exports.getHomeGoodList = (req, res, next) => {

}
