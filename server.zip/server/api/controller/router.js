// var homeController = require('./home')
var userController = require('./user')

exports.getInfo = userController.getInfo
