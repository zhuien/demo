module.exports = {
  host: '192.168.0.160',
  user: 'root',
  password: 'root',
  port: '3306',
  database: 'zzz_shopping',
  connectionLimit: 10
}
