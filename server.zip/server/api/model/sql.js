// 查询用户信息
exports.getUserInfo = id => {
  return `select * from zzz_members where apid = ${id}`
}
